A execução do programa está descrita como na especificação.

python3 router.py 'ip' 'period' 'startup' (1)
ou
python3 router.py --addr 'ip' --update-period 'period' --startup-commands (2)	

obs: A forma de entrada (2) não foi testada adequadamente, pois não ficou claro na especificação.   
